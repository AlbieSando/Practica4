# PRACTICA_3
Este repositorio contiene los códigos necesario para el funcionamiento de la Práctica 3. La cual consiste en un multiplicador veloz de matriz por vector.
